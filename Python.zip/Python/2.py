print("Enter two numbers:")
a=int(input("Enter the a:"))
b=int(input("Enter the b:"))
c=a+b
print("Sum=",c)
